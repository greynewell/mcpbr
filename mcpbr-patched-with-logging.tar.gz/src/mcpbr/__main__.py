"""Entry point for running mcpbr as a module with python -m mcpbr."""

from .cli import main

if __name__ == "__main__":
    main()
